/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.content.registry.fluid;

import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import net.neoforged.neoforge.fluids.FluidType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.world.entity.EntityFluidInteraction;

@Mixin(EntityFluidInteraction.class)
public interface EntityFluidInteractionAccessor {
	// 26.3: per-fluid current state lives in currentAccumulators (keyed by FluidType on NeoForge)
	@Accessor("currentAccumulators")
	Reference2ObjectMap<FluidType, Object> getCurrentAccumulators();
}
