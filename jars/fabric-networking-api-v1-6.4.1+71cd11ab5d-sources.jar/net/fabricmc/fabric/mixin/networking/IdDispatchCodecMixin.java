/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.networking;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.VarInt;
import net.minecraft.network.codec.IdDispatchCodec;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.CommonPacketTypes;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

@Mixin(IdDispatchCodec.class)
public abstract class IdDispatchCodecMixin<B extends ByteBuf, V, T> implements StreamCodec<B, V> {
	// Add the custom payload id to the error message
	@Inject(method = "encode(Lio/netty/buffer/ByteBuf;Ljava/lang/Object;)V", at = @At(value = "NEW", target = "(Ljava/lang/String;Ljava/lang/Throwable;)Lio/netty/handler/codec/EncoderException;"))
	public void encode(B byteBuf, V packet, CallbackInfo ci, @Local(name = "type") T packetType, @Local(name = "e") Exception e) {
		CustomPacketPayload payload = null;

		if (packet instanceof ServerboundCustomPayloadPacket customPayloadPacket) {
			payload = customPayloadPacket.payload();
		} else if (packet instanceof ClientboundCustomPayloadPacket customPayloadPacket) {
			payload = customPayloadPacket.payload();
		}

		if (payload != null && payload.type() != null) {
			throw new EncoderException("Failed to encode packet '%s' (%s)".formatted(packetType, payload.type().id().toString()), e);
		}
	}

	// Add the custom payload id to the error message
	@Inject(method = "decode(Lio/netty/buffer/ByteBuf;)Ljava/lang/Object;", at = @At("HEAD"))
	public void decode(B input, CallbackInfoReturnable<V> cir, @Share("copy") LocalRef<ByteBuf> copy) {
		copy.set(input.duplicate());
	}

	@Inject(method = "decode(Lio/netty/buffer/ByteBuf;)Ljava/lang/Object;", at = @At(value = "NEW", target = "(Ljava/lang/String;Ljava/lang/Throwable;)Lio/netty/handler/codec/DecoderException;"))
	public void decode(B input, CallbackInfoReturnable<V> cir, @Local(name = "entry") IdDispatchCodec.Entry<B, V, T> entry, @Local(name = "e") Exception e, @Share("copy") LocalRef<ByteBuf> copy) {
		if (entry.type() == CommonPacketTypes.CLIENTBOUND_CUSTOM_PAYLOAD || entry.type() == CommonPacketTypes.SERVERBOUND_CUSTOM_PAYLOAD) {
			Identifier identifier;

			try {
				FriendlyByteBuf friendlyByteBuf = new FriendlyByteBuf(copy.get());
				int _ = VarInt.read(friendlyByteBuf);
				// see CustomPacketPayload$1#decode
				identifier = friendlyByteBuf.readIdentifier();
			} catch (Throwable t) {
				// we weren't able to recover the id, fallback to vanilla's exception handling
				return;
			}

			throw new DecoderException("Failed to decode packet '%s' (%s)".formatted(entry.type(), identifier), e);
		}
	}
}
