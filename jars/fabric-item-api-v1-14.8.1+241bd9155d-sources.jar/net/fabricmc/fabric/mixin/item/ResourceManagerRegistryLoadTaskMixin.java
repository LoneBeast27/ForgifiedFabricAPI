/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.item;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.datafixers.util.Either;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.core.RegistrationInfo;
import net.minecraft.core.component.BlockTransformer;
import net.minecraft.resources.RegistryLoadTask;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceManagerRegistryLoadTask;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.world.item.enchantment.Enchantment;

import net.fabricmc.fabric.impl.item.BlockTransformerHelperImpl;
import net.fabricmc.fabric.impl.item.EnchantmentUtil;
import net.fabricmc.fabric.impl.item.ResourceUtil;

@Mixin(ResourceManagerRegistryLoadTask.class)
public class ResourceManagerRegistryLoadTaskMixin {
	@Unique
	private volatile RegistryOps.RegistryInfoLookup registryInfoLookup;

	@SuppressWarnings({"unchecked"})
	@WrapOperation(method = "lambda$load$2", at = @At(value = "NEW", target = "net/minecraft/resources/RegistryLoadTask$PendingRegistration"))
	private <T> RegistryLoadTask.PendingRegistration<?> modify(ResourceKey<T> key, Either<T, Exception> value, RegistrationInfo registrationInfo, Operation<RegistryLoadTask.PendingRegistration<T>> original, @Local(argsOnly = true) Resource resource) {
		if (value.left().isPresent()) {
			T leftValue = value.left().get();
			T modified = null;

			if (leftValue instanceof Enchantment enchantment) {
				modified = (T) EnchantmentUtil.modify((ResourceKey<Enchantment>) key, enchantment, ResourceUtil.determineSource(resource), registryInfoLookup);
			} else if (leftValue instanceof BlockTransformer blockTransformer) {
				modified = (T) BlockTransformerHelperImpl.modify((ResourceKey<BlockTransformer>) key, blockTransformer, ResourceUtil.determineSource(resource), registryInfoLookup);
			}

			if (modified != null) {
				// Clear the knownPackInfo to force the server to sync the data pack to the client
				registrationInfo = new RegistrationInfo(Optional.empty(), registrationInfo.lifecycle());
				value = Either.left(modified);
			}
		}

		return original.call(key, value, registrationInfo);
	}

	@Inject(method = "load", at = @At("HEAD"))
	private void captureRegistries(RegistryOps.RegistryInfoLookup context, Executor executor, CallbackInfoReturnable<CompletableFuture<?>> cir) {
		this.registryInfoLookup = context;
	}
}
